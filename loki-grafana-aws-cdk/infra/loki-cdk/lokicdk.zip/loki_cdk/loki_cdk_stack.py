from aws_cdk import (
    CfnOutput,
    Stack,
)
from aws_cdk import aws_ec2 as ec2
from constructs import Construct


class LokiCdkStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Get the VPC
        vpc = ec2.Vpc.from_lookup(self,
                                  "SatVPC",
                                  vpc_id="vpc-0c15d73d7a3968763"
                                  )

        # Create a Security Group
        security_group = ec2.SecurityGroup(
            self, 'GrafanaPublicEc2SecurityGroup',
            vpc=vpc,
            allow_all_outbound=True  # Allow outbound traffic
        )
        security_group.add_ingress_rule(ec2.Peer.any_ipv4(), ec2.Port.tcp(22), 'SSH access from anywhere')
        security_group.add_ingress_rule(ec2.Peer.any_ipv4(), ec2.Port.tcp(80), 'HTTP access from anywhere')
        security_group.add_ingress_rule(ec2.Peer.any_ipv4(), ec2.Port.tcp(3000), 'Grafana port access from anywhere')
        # Does the UI need loki port 3100 open?

        # Create a key pair for SSH access
        key_pair = ec2.KeyPair.from_key_pair_name(self, "FinTechUSWest2KeyPair", key_pair_name="fintech-us-west-2-key")

        machine_image = ec2.AmazonLinuxImage(generation=ec2.AmazonLinuxGeneration.AMAZON_LINUX_2)

        # define what is needed like UserData etc.
        with open("loki_cdk/user_data_loki_ec2_inst.sh") as user_data_file:
            user_data = user_data_file.read()

        # create the EC2-Instance
        instance = ec2.Instance(
            self, 'GrafanaLokiServer',
            instance_type=ec2.InstanceType.of(ec2.InstanceClass.T2, ec2.InstanceSize.MICRO),  # T2 Micro instance
            machine_image=machine_image,
            security_group=security_group,
            key_pair=key_pair,
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PUBLIC),
            user_data=ec2.UserData.custom(user_data)
        )

        # get the IP address of the EC2 Instance to put as output needed for promtail script.
        CfnOutput(self, "loki_push_logs_url",
                  value=f"{instance.instance_private_ip}:3100",
                  export_name="loki-push-logs-url")
